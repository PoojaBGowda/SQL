CREATE DATABASE Employee

CREATE DATABASE TestData1
 CONTAINMENT = NONE
 ON  PRIMARY 
(
 NAME = N'TestData1',
 FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\TestData1.mdf' ,
 SIZE = 10MB , 
 MAXSIZE = UNLIMITED, 
 FILEGROWTH = 1MB
  )
 LOG ON 
( 
NAME = N'TestData1_log', 
FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\TestData1_log.ldf' , 
SIZE = 1MB , 
MAXSIZE = 2048GB ,
 FILEGROWTH = 10%
 )
GO


USE TestData1
GO
CREATE TABLE Product
(
Pid INT IDENTITY NOT NULL PRIMARY KEY,
Pname varchar(50) NOT NULL,
Cid INT NOT NULL REFERENCES Categories(Cid)
)
CREATE TABLE Categories
(
Cid INT IDENTITY NOT NULL PRIMARY KEY,
Cname varchar(50) NOT NULL
)

INSERT INTO Categories
VALUES ('Groceries')

INSERT INTO Categories
VALUES ('Hardware'),
	   ('Cosmetics'),
	   ('Fruits')

INSERT INTO Product(Pname,Cid)
VALUES ('bASMATHI Rice',1),
	   ('Dove soap',3),
	   ('Screwdriver',2)

INSERT INTO Product
VALUES('Apples',4)

SELECT * FROM Product

SELECT * FROM Categories

UPDATE
	 Categories
SET
	Cname='Cosmetics'
where
	Cid=1

SELECT * FROM Categories

UPDATE
	 Categories
SET
	Cname='Groceries'
where
	Cid=1

SELECT * FROM Categories




CREATE DATABASE 
	AdventureWorks2012
ON PRIMARY
	(
	 FILENAME=N'D:\AdventureWorksDW2012_Data.mdf'
	 )
FOR
    ATTACH_REBUILD_LOG;

SELECT *  
FROM DimEmployee  
ORDER BY LastName; 

SELECT *  
FROM DimEmployee  
ORDER BY LastName DESC; 

SELECT e.*  
FROM DimEmployee AS e  
ORDER BY LastName;  

SELECT FirstName, LastName, StartDate AS FirstDay  
FROM DimEmployee   
ORDER BY LastName;  

SELECT FirstName, LastName, StartDate AS FirstDay  
FROM DimEmployee   
WHERE EndDate IS NOT NULL   
AND MaritalStatus = 'M'  
ORDER BY LastName; 

SELECT FirstName, LastName, BaseRate, BaseRate * 40 AS GrossPay  
FROM DimEmployee  
ORDER BY LastName; 

SELECT DISTINCT Title  
FROM DimEmployee  
ORDER BY Title;  

SELECT * FROM FactInternetSales

SELECT OrderDateKey, SUM(SalesAmount) AS TotalSales  
FROM FactInternetSales  
GROUP BY OrderDateKey  
ORDER BY OrderDateKey  

SELECT OrderDateKey, PromotionKey, AVG(SalesAmount) AS AvgSales, SUM(SalesAmount) AS TotalSales  
FROM FactInternetSales  
GROUP BY OrderDateKey, PromotionKey  
ORDER BY OrderDateKey


 SELECT OrderDateKey, SUM(SalesAmount) AS TotalSales  
FROM FactInternetSales  
WHERE OrderDateKey > '20020801'  
GROUP BY OrderDateKey  
ORDER BY OrderDateKey;  


SELECT SUM(SalesAmount) AS TotalSales  
FROM FactInternetSales  
GROUP BY (OrderDateKey * 10);  

SELECT OrderDateKey, SUM(SalesAmount) AS TotalSales  
FROM FactInternetSales  
GROUP BY OrderDateKey  
ORDER BY OrderDateKey;  


SELECT OrderDateKey, SUM(SalesAmount) AS TotalSales  
FROM FactInternetSales  
GROUP BY OrderDateKey  
HAVING OrderDateKey > 20010000  
ORDER BY OrderDateKey;


/*JOINS*/


SELECT * FROM Product,Categories
WHERE Product.Cid=Categories.Cid;

SELECT Pname,Cname
FROM Product P,Categories C
WHERE P.Cid=C.Cid;

SELECT Pname,Cname
FROM Product P JOIN Categories C
ON P.Cid=C.Cid AND C.Cid>2;

SELECT Pname,Cname,C.Cid
FROM Product P JOIN Categories C
ON C.Cid>2 and p.Cid>2;

SELECT * FROM Categories;

select CategoryName,Cname
from Northwind.dbo.Categories n
join TestData1.dbo.Categories t on n.CategoryID = t.Cid



USE Northwind
GO

SELECT * FROM Employees

SELECT * FROM Employees WHERE City='London'

SELECT * FROM Employees WHERE TitleOfCourtesy='Mr.'

/*VIEWS*/

USE northwind
--If exist (drop view)
--Else
CREATE VIEW prod_12
AS
SELECT *
FROM products
WHERE productID IN(1,2)

SELECT *
FROM prod_12

/*eXCEPTION*/
Use Northwind
BEGIN TRY
-----Try and create our table
CREATE TABLE test_table(
col1 int primary key
)
END TRY
--SELECT * FROM ERRORLOG
BEGIN CATCH
DECLARE @ErrorNo int,
@Severity tinyint,
@State smallint,
@LineNo int,
@Message nvarchar(4000)
SELECT
@ErrorNo = ERROR_NUMBER(),
@Severity = ERROR_SEVERITY(),
@State = ERROR_STATE(),
@LineNo = ERROR_LINE(),
@Message = ERROR_MESSAGE()
IF @ErrorNo = 2714
print 'WARNING: Skipping CREATE table already exists'
ELSE
RAISERROR(@Message,16,1)
END CATCH


/*USING CURSORS*/

USE Northwind
--1. Declare cursor as fast,forward and read ony
DECLARE cDetail CURSOR FAST_FORWARD READ_ONLY
FOR SELECT FirstName
From Employees
--2. open cDetail
OPEN cDetail
--3. Prime the cursor
DECLARE @Name Varchar(20)
FETCH cDetail INTO @Name
PRINT @Name
WHILE @@FETCH_STATUS=0
	BEGIN
		FETCH cDetail INTO @Name
		PRINT @Name
		
	END
--4. close the cursor
CLOSE cDetail
--5. Deallocate the cursor
DEALLOCATE cDetail

/*STORY PROCEDURE*/
--PROCEDURE can be used as PROC
CREATE PROCEDURE 
   sp_employees_in_us
   @CountryName VARCHAR(20),
   @Title VARCHAR(10)
AS
	SELECT* FROM Employees
	WHERE Country = @CountryName
	AND TitleOfCourtesy=@Title
	
EXECUTE sp_employees_in_us @CountryName='USA',@Title='Ms.'

DROP PROCEDURE sp_employees_in_us


/*TRIGGER*/

GO
CREATE TRIGGER ConvertOnInsert1
ON Employees
AFTER INSERT , UPDATE
AS
	BEGIN
		UPDATE Employees
		SET FirstName=UPPER(Firstname)
		WHERE EmployeeId IN (SELECT EmployeeId FROM INSERTED)
	END

GO


SELECT * FROM Employees


INSERT INTO Employees(FirstName,LastName)
VALUES ('Anand','Mahindra')


/*

