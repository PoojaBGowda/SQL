
/* 1. CREATING DATABASE*/

CREATE DATABASE CustomerData

CREATE TABLE pack_grades
(
grade_id int NOT NULL PRIMARY KEY,
grade_name varchar(15),
min_price INT,
max_price INT
)
CREATE TABLE sectors
(
sector_id INT  not null PRIMARY KEY,
sector_name VARCHAR(15)
)

CREATE TABLE packages
(
pack_id INT  NOT NULL PRIMARY KEY,
speed VARCHAR(15),
strt_date DATE,
monthly_payment INT,
sector_id INT REFERENCES sectors(sector_id)
)

/* 2. CREATING customers TABLE*/

CREATE TABLE customers
(
Customer_id INT  NOT NULL PRIMARY KEY,
First_name VARCHAR(15),
Last_name VARCHAR(15),
Birth_date DATE,
join_date DATE,
city VARCHAR(15),
customerstate VARCHAR(15),
street VARCHAR(25),
main_phone_num VARCHAR(20),
secondary_phone_num VARCHAR(20),
fax varchar(15),
monthly_discount float,
pack_id INT REFERENCES packages(pack_id)
)

/*INSERTING VALUES TO THE TABLES*/

INSERT pack_grades VALUES (1,'Very Low', 0, 10)
INSERT pack_grades VALUES (2,'Low', 11, 20)
INSERT pack_grades VALUES (3,'Medium', 21, 40)
INSERT pack_grades VALUES (4,'High', 41, 80)
INSERT pack_grades VALUES (5,'Very High', 81, 150)

INSERT sectors VALUES(1,'Private')
INSERT sectors VALUES(2,'Business')


INSERT packages VALUES(1,'750Kbps',CAST(0x5C2C0B00 AS Date),79,1)
INSERT packages VALUES(2,'750Kbps',CAST(0x8D2D0B00 AS Date),69,1)
INSERT packages VALUES(3,'750Kbps',CAST(0x092E0B00 AS Date),59,1)
INSERT packages VALUES(4,'750Kbps',CAST(0x05300B00 AS Date),49,1)
INSERT packages VALUES(5,'750Kbps',CAST(0xF9310B00 AS Date),39,1)
INSERT packages VALUES(6,'750Kbps',CAST(0x51320B00 AS Date),29,1)
INSERT packages VALUES(7,'750Kbps',CAST(0xA42B0B00 AS Date),69,2)
INSERT packages VALUES(8,'750Kbps',CAST(0x7D2D0B00 AS Date),59,2)
INSERT packages VALUES(9,'750Kbps',CAST(0x342F0B00 AS Date),49,2)
INSERT packages VALUES(10,'750Kbps',CAST(0x9C300B00 AS Date),39,2)
INSERT packages VALUES(11,'750Kbps',CAST(0x29320B00 AS Date),29,2)
INSERT packages VALUES(12,'750Kbps',CAST(0x2C330B00 AS Date),19,2)
INSERT packages VALUES(13,'1.5Mbps',CAST(0xBD2C0B00 AS Date),89,1)
INSERT packages VALUES(14,'1.5Mbps',CAST(0xB52E0B00 AS Date),79,1)
INSERT packages VALUES(15,'1.5Mbps',CAST(0xA2300B00 AS Date),69,1)
INSERT packages VALUES(16,'1.5Mbps',CAST(0x8F310B00 AS Date),59,1)
INSERT packages VALUES(17,'1.5Mbps',CAST(0x76320B00 AS Date),49,1)
INSERT packages VALUES(18,'1.5Mbps',CAST(0x3B2D0B00 AS Date),79,2)
INSERT packages VALUES(19,'1.5Mbps',CAST(0x3C2E0B00 AS Date),69,2)
INSERT packages VALUES(20,'1.5Mbps',CAST(0xA02F0B00 AS Date),59,2)
INSERT packages VALUES(21,'1.5Mbps',CAST(0x4A310B00 AS Date),49,2)
INSERT packages VALUES(22,'1.5Mbps',CAST(0x5F320B00 AS Date),39,2)
INSERT packages VALUES(23,'2.5Mbps',CAST(0x0C2E0B00 AS Date),99,1)
INSERT packages VALUES(24,'2.5Mbps',CAST(0xD82F0B00 AS Date),89,1)
INSERT packages VALUES(25,'2.5Mbps',CAST(0xC6310B00 AS Date),79,1)
INSERT packages VALUES(26,'2.5Mbps',CAST(0x09330B00 AS Date),69,1)
INSERT packages VALUES(27,'2.5Mbps',CAST(0x8B2E0B00 AS Date),89,2)
INSERT packages VALUES(28,'2.5Mbps',CAST(0x7C2F0B00 AS Date),79,2)
INSERT packages VALUES(29,'2.5Mbps',CAST(0xEC300B00 AS Date),69,2)
INSERT packages VALUES(30,'2.5Mbps',CAST(0x66320B00 AS Date),59,2)

INSERT customers VALUES(1,'Alvin','Smith','1962-06-27',CAST(0x812D0B00 AS
Date),'NewYork','NewYork','5953HollisterAvenue','567.867.3945','936.228.9436','762.788.3400',CAST(28.00 AS Decimal(4,2)),18)
INSERT customers VALUES(2,'Jose','Jones','1968-01-17',CAST(0x12300B00 AS
Date),'LosAngeles','California','4081HollisterAvenue','520.336.8373','939.115.6982','7
11.883.3345',CAST(12.00 AS Decimal(4,2)),31)
INSERT customers VALUES(3,'Amado','Taylor','1965-08-17',CAST(0x802C0B00 AS
Date),'Chicago','Illinois','3402BroderickStreet','522.501.6331','976.113.3737','767.94
4.7131',NULL,7)
INSERT customers VALUES(4,'Stuart','Williams','1983-05-01',CAST(0xF32E0B00 AS
Date),'Houston','Texas','5543JenningsStreet','530.339.4737','963.891.4185','756.186.36
34',CAST(17.00 AS Decimal(4,2)),23)
INSERT customers VALUES(5,'Demarcus','Brown','1971-12-02',CAST(0xD62C0B00 AS
Date),'Philadelphia','Pennsylvania','5321LagunaStreet','580.733.2184',NULL,'760.663.20
46',CAST(11.00 AS Decimal(4,2)),13)
INSERT customers VALUES(6,'Mark','Davies','1970-09-01',CAST(0xAB310B00 AS
Date),'Phoenix','Arizona','5868CameronWay','557.701.1366','919.345.5511',NULL,CAST(18.00 AS Decimal(4,2)),39)
INSERT customers VALUES(7,'Merlin','Evans','1962-04-13',CAST(0xD52B0B00 AS
Date),'SanAntonio','Texas','8177BrannanStreet','542.753.9215','992.959.8999',NULL,CAST
(23.00 AS Decimal(4,2)),1)
INSERT customers VALUES(8,'Elroy','Wilson','1963-01-28',CAST(0x19330B00 AS
Date),'SanDiego','California','1873KeyAvenue','544.172.1347','985.345.8501',NULL,CAST(
6.00 AS Decimal(4,2)),42)
INSERT customers VALUES(9,'Charles','Thomas','1960-05-13',CAST(0x44320B00 AS
Date),'SanJose','California','9164ValenciaStreet','515.656.3047',NULL,'799.101.7626',CAST(29.00 AS Decimal(4,2)),37)
INSERT customers VALUES(10,'Rudolph','Roberts','1973-11-05',CAST(0x412C0B00 AS
Date),'Jacksonville','Florida','6308GilbertStreet','549.569.1762','942.671.2496','729.
973.1742',CAST(7.00 AS Decimal(4,2)),7)
INSERT customers VALUES(11,'Laurence','Johnson','1975-11-25',CAST(0xC62F0B00 AS
Date),'Indianapolis','Indiana','7529McLarenAvenue','527.138.3311','916.219.9787',NULL,
CAST(9.00 AS Decimal(4,2)),34)
INSERT customers VALUES(12,'Pasquale','Lewis','1969-05-24',CAST(0x162F0B00 AS
Date),'Austin','Texas','1569ClevelandStreet','566.849.6722','983.706.4341',NULL,NULL,27)
INSERT customers VALUES(13,'Pat','Walker','1985-07-02',CAST(0x8D300B00 AS
Date),'SanFrancisco','California','4687SloatBoulevard','582.885.8362','938.219.8802',NULL,NULL,31)
INSERT customers VALUES(14,'Harland','Robinson','1974-04-17',CAST(0xFD2F0B00 AS
Date),'Columbus','Ohio','5390MontgomeryStreet','520.519.1795','944.392.2529','721.443.
8826',CAST(30.00 AS Decimal(4,2)),31)
INSERT customers VALUES(15,'Herschel','Wood','1974-07-24',CAST(0xE9320B00 AS
Date),'FortWorth','Texas','7842CorbettAvenue','588.826.5279','997.263.1636','779.791.4
617',CAST(30.00 AS Decimal(4,2)),41)
INSERT customers VALUES(16,'Galen','Thompson','1964-12-08',CAST(0x902B0B00 AS
Date),'Charlotte','NorthCarolina','5466FarragutAvenue','599.783.7133',NULL,'753.251.64
33',CAST(16.00 AS Decimal(4,2)),1)
INSERT customers VALUES(17,'Brain','White','1978-02-13',CAST(0x1F300B00 AS
Date),'Detroit','Michigan','3728IngersonStreet','561.654.2679','957.711.4041','794.811
.7354',NULL,34)
INSERT customers VALUES(18,'Marcel','Watson','1978-10-12',CAST(0x452E0B00 AS
Date),'ElPaso','Texas','9157LeidesdorffStreet','567.827.2421','937.806.4116','723.277.
6166',CAST(28.00 AS Decimal(4,2)),23)
INSERT customers VALUES(19,'Lino','Jackson','1982-06-25',CAST(0x2E2E0B00 AS
Date),'Memphis','Tennessee','4542McKinnonAvenue','557.460.8507','984.433.8202','792.90
8.7024',CAST(6.00 AS Decimal(4,2)),27)
INSERT customers VALUES(20,'Riley','Wright','1970-02-18',CAST(0x2B2B0B00 AS
Date),'Boston','Massachusetts','4848VallejoStreet','541.661.3366','931.368.3046','737.
625.7424',CAST(21.00 AS Decimal(4,2)),1)

/* 3.CREATE A QUERY TO DISPLAY ALL THE DATA FROM THE CUSTOMERS TABLE*/

SELECT * FROM customers

 /*4. CREATE A QUERY TO DISPLAY THE INTERNET PACKAGE NUMBER, INTERNET SPEED AND MONTHLY
PAYMENT (Packages table).*/

SELECT pack_id,speed,monthly_payment
FROM packages

/*5. CREATE A QUERY TO DISPLAY THE CUSTOMER NUMBER, FIRST NAME, LAST NAME, PRIMARY PHONE
NUMBER, SECONDARY PHONE NUMBER AND PACKAGE NUMBER (Customers table).*/

SELECT Customer_id,
	   First_name, 
	   Last_name,
	   main_phone_num,
	   secondary_phone_NUM,
	   pack_id
FROM customers

/*6. CREATE A QUERY TO DISPLAY FIRST NAME, LAST NAME, JOIN DATE, MONTHLY DISCOUNT, MONTHLY
DISCOUNT AFTER AN ADDITION OF 20% AND MONTHLY DISCOUNT AFTER A REDUCTION OF
20% (Customers table).*/


SELECT First_name, 
	   Last_name,
	   join_date,
	   monthly_discount,
	   monthly_discount+(monthly_discount*(20/100))as discount_add_20per,
	   monthly_discount-(monthly_discount*(20/100)) as discount_minus_20per
FROM customers

/*7. CREATE A QUERY TO DISPLAY THE PACKAGE NUMBER, SPEED, STRT_DATE (THE DATE WHEN THE
PACKAGE BECAME AVAILABLE), MONTHLY PAYMENT, AND MONTHLY PAYMENT * 12, NAME THE
LAST COLUMN �YEARLYPAYMENT� (Packages table).*/

SELECT pack_id,
	   speed,
	   strt_date,
	   monthly_payment,
	   monthly_payment*12 as YEARLY_PAYMENT
FROM packages

/*8. CREATE A QUERY TO DISPLAY THE LAST NAME CONCATENATED WITH THE FIRST NAME, SEPARATED BY
SPACE, AND MAIN PHONE NUMBER CONCATENATED WITH SECONDARY PHONE NUMBER,
SEPARATED BY COMMA AND SPACE. NAME THE COLUMN HEADING FULL_NAME AND
CONTACT_DETAILS RESPECTIVELY. (Customers table)*/

SELECT CONCAT(First_name,' ',last_name) as FULL_NAME,
	   CONCAT(main_phone_num,' ',secondary_phone_num) as CONTACT_DETAILS
FROM customers

/*9. CREATE A QUERY TO DISPLAY UNIQUE CITIES FROM THE CUSTOMERS TABLE.*/

SELECT DISTINCT city from customers

/*10. CREATE A QUERY TO DISPLAY UNIQUE STATES FROM THE CUSTOMERS TABLE.*/

SELECT DISTINCT customerstate from customers

/*11. CREATE A QUERY TO DISPLAY UNIQUE COMBINATION OF CITIES AND STATES FROM customers
TABLE.*/

SELECT DISTINCT customerstate,city from customers

/*12. CREATE A QUERY TO DISPLAY THE LAST NAME CONCATENATED WITH THE STATE, SEPARATED BY
SPACE. NAME THIS COLUMN CUSTOMER_AND_STATE (customers TABLE)*/

SELECT CONCAT(last_name,' ',customerstate) as CUSTOMER_AND_STATE FROM customers

/*13. CREATE A QUERY TO DISPLAY THE FIRST NAME, LAST NAME, MONTHLY DISCOUNT AND CITY
CONCATENATED WITH STREET, SEPARATED BY SPACE. NAME THE COLUMN HEADINGS: FN, LN, DC
AND FULL_ADDRESS RESPECTIVELY (Customers table).*/

SELECT first_name as FN,
	   last_name as LN,
	   monthly_discount as DC,
	   CONCAT(city,' ',street) as FULL_ADDRESS
FROM customers

/*14. CREATE A QUERY TO DISPLAY UNIQUE MONTHLY DISCOUNTS IN CUSTOMERS TABLE.*/

SELECT DISTINCT monthly_discount FROM customers

/*15. CREATE A QUERY TO DISPLAY UNIQUE PACKAGES (PACKAGE_ID) IN CUSTOMERS TABLE.*/

SELECT DISTINCT pack_id from customers

/*16. DISPLAY THE FIRST NAME, LAST NAME, AND PACKAGE NUMBER FOR ALL CUSTOMERS WHOSE LAST
NAME IS �KING� (Customers table).*/

SELECT first_name,last_name,pack_id
FROM customers
WHERE last_name='KING';

/*17. DISPLAY ALL THE DATA FROM PACKAGES TABLE FOR PACKAGES WHOSE SPEED IS �5Mbps�.*/

SELECT * FROM packages
WHERE speed='5mbps';

/*18. DISPLAY THE FIRST NAME, LAST NAME, PACKAGE NUMBER AND MONTHLY DISCOUNT FOR ALL
CUSTOMERS WITH MONTHLY DISCOUNT LESS THAN 30 (Customers table).*/

SELECT first_name,last_name,pack_id,monthly_discount
FROM customers
WHERE monthly_discount<30;

/*19. DISPLAY ALL THE DATA FROM CUSTOMERS TABLE FOR ALL CUSTOMERS WHO JOINED THE COMPANY
BEFORE January 1st, 2007.*/

SELECT * FROM customers
WHERE join_date<'2007/1/1'

/*20. DISPLAY THE CUSTOMER NUMBER, FIRST NAME ,STATE, CITY AND PACKAGE NUMBER FOR ALL
CUSTOMERS WHOSE PACKAGE NUMBER EQUALS 21, 28, or 14 (Customers table).*/

SELECT Customer_id,first_name,last_name,customerstate,city,pack_id
from customers
WHERE pack_id IN(21,28,14)

/*21. DISPLAY THE CUSTOMER NUMBER, FIRST NAME ,STATE, CITY AND PACKAGE NUMBER FOR ALL
CUSTOMERS WHOSE PACKAGE NUMBER IS NOT EQUAL to 27, 10, or 3 (Customers table).*/

SELECT Customer_id,first_name,last_name,customerstate,city,pack_id
from customers
WHERE pack_id NOT IN(27,10,3)

/*22. DISPLAY THE LAST NAME, MAIN PHONE NUMBER, MONTHLY DISCOUNT AND PACKAGE NUMBER FOR
ALL CUSTOMERS WHOSE CUSTOMER NUMBER EQUALS 703, 314 or 560 (Customers table)*/

SELECT last_name,main_phone_num,monthly_discount,pack_id
FROM customers
WHERE Customer_id IN(703,314,560)

/*23. DISPLAY THE FIRST NAME AND MONTHLY DISCOUNT FOR ALL CUSTOMERS WHOSE FIRST NAME ENDS
WITH AN e (Customers table).*/

SELECT first_name,monthly_discount
FROM customers
WHERE first_name like '%e'

/*24. DISPLAY THE LAST NAME AND PACKAGE NUMBER FOR ALL CUSTOMERS WHERE THE SECOND LETTER
OF THEIR LAST NAME IS d (Customers table).*/

SELECT Last_name,pack_id
FROM customers
WHERE Last_name like '%d_'

/*25. DISPLAY ALL THE DATA FROM CUSTOMERS TABLE FOR ALL CUSTOMERS WHO HAVE THE LETTERS: L, J OR
H IN THEIR LAST NAME. ORDER THE QUERY IN DESCENDING ORDER BY monthly discount
(Customers table).*/

SELECT * FROM customers
WHERE Last_name LIKE '%L%' OR Last_name LIKE'%J%' OR Last_name LIKE '%H%'
ORDER BY monthly_discount desc

/*26. DISPLAY THE FIRST NAME, JOIN DATE, MONTHLY DISCOUNT AND PACKAGE NUMBER FOR ALL
CUSTOMERS WHO DON�T HAVE THE LETTER A IN THEIR LAST NAME. ORDER THE QUERY IN ASCENDING
ORDER BY PACKAGE NUMBER (Customers table).*/

SELECT first_name,join_date,monthly_discount,pack_id
FROM customers
WHERE last_name NOT LIKE '%A%'
ORDER BY pack_id

/*27. DISPLAY ALL DATA FROM CUSTOMERS TABLE FOR ALL CUSTOMERS WITHOUT A PACKAGE (package
number is null)*/

SELECT * FROM customers where pack_id is null;

/*28. Display the first name concatenated with the last name (separated by space), and
monthly discount for all customers whose monthly discount is not in the range
between 20 and 30. Order the query in ascending order by the full name (Customers
table).*/

SELECT CONCAT(first_name,last_name)  AS FULL_NAME FROM customers
WHERE monthly_discount NOT BETWEEN 20 AND 30
ORDER BY FULL_NAME

/*29. Display the first name concatenated with the last name (separated by space), the main
phone number concatenated with street (separated by space), and monthly discount
for all customers whose monthly discount is in the range between 11 and 27. Name
the column headings FULL_NAME, CONTACTS, and DC respectively (Customers
table).*/

SELECT CONCAT(first_name,' ',last_name) as FULL_NAME,
	   CONCAT(main_phone_num,' ',street) as CONTACTS,
	   monthly_discount	
FROM customers
WHERE monthly_discount BETWEEN 11 AND 27

/*30. Display all data from Customers table for :
a. All customers who live in New York and whose monthly discount is in the range
between 30 and 40 or
b. All customers whose package number is not 8,19, or 30 and whose join date is
before January 1st, 2007*/

SELECT * FROM customers
WHERE (city = 'NEWYORK' AND monthly_discount BETWEEN 20 AND 30) OR (pack_id NOT IN(8,19,30) AND join_date < '2007/1/1' ) 

/*31. Display the last name, package number, and birthdate for all customers whose join
date is in the range between December 12th, 2007 and April 17th, 2010 (Customers
table).*/

SELECT last_name,pack_id,join_date FROM customers
WHERE join_date BETWEEN '2007/12/12' AND '2010/04/17'

/*32. Display the package number, start date, and speed for all packages whose start date is
before January 1st, 2007 (Packages table)*/

SELECT pack_id,strt_date,speed FROM packages
WHERE strt_date < '2007/1/1'

/*33. Display the package number, speed, and sector number for all packages whose sector
number equals 1 (Packages table).*/

SELECT pack_id,strt_date, sector_id FROM packages
WHERE sector_id = 1

/*34. Display the package number, speed and sector number for all packages with internet
speed of �5Mbps� or �10Mbps� (Packages table).*/

SELECT pack_id,speed, sector_id FROM packages
WHERE speed IN('5MBPS','10MBPS')

/*35. Display the last name and monthly discount for all customers live in Orlando
(Customers table).*/

SELECT last_name ,monthly_discount FROM customers
WHERE customerstate = 'orlando'

/*36. Display the last name and package number for all customers whose package number
equals 9 or 18. Preform the exercise once using IN operator, once using OR
(Customers table).*/

SELECT last_name,pack_id FROM customers
WHERE pack_id = 9 OR pack_id = 18

SELECT last_name,pack_id FROM customers
WHERE pack_id in(9,18)

/*37. Display the first name, main phone number and secondary phone number for all
customers without a secondary phone number (secondary phone number is null).*/

select first_name,main_phone_num,secondary_phone_num from customers
where secondary_phone_num IS NULL

/*38. Display the first name, monthly discount and package id for all customers without any
monthly discount (monthly discount is null).*/

select first_name,monthly_discount ,pack_id from customers
where monthly_discount IS NULL

/*39. Display the customer number, first name in lowercase and last name in uppercase for
all customers whose customer number is in the range of 80 and 150.*/

select Customer_id,lower(first_name),upper(last_name) from customers
where Customer_id between 8 and 10

/*40. Generating Email Addresses
a. For all customers � display the last name, first name and email address. The
email address will be composed from the first letter of first name
concatenated with three first letters of last name concatenated with the string
�@mymail.com� (For example : Ram Kedem ? RKED@mymail.com).*/

select first_name,last_name ,CONCAT(LEFT(first_name,1),LEFT(last_name,3),'@myemail.com') as email from customers

/*b. For all customers � display the last name, first name and email address. The
email address will be composed from the first letter of first name
concatenated with three last letters of last name concatenated with the string
�@mymail.com� (For example : Ram Kedem ? RDEM@mymail.com).*/

select first_name,last_name ,CONCAT(LEFT(first_name,1),RIGHT(last_name,3),'@myemail.com') as email from customers

/*41. Display the last name and the length of the last name for all customers where last
name�s length is greater than 9 characters.*/

select last_name ,len(last_name) as lengthoflast_name from customers
where len(last_name)>9

/*42. Phone Numbers :
a. Display the first name, last name, main phone number and a new phone
number using the REPLACE function. In the new phone number
replace all occurrences of �515� with �$$$�.*/

select first_name,last_name,main_phone_num,REPLACE(main_phone_num , '519' ,'$$$') as newphonenumber from customers
where main_phone_num like '%519%'

/*b. Display the first name, last name, main phone number and new phone number
using the REPLACE function. In the new phone number replace all prefixes of
�515� with �$$$� (only if the first 3 digits of the phone number contains the
digits �515� replace those digits with �$$$�).*/

select first_name,last_name,main_phone_num,REPLACE(main_phone_num , '519' ,'$$$') as newphonenumber from customers
where main_phone_num like '519%'

/*43. From customers table, for all customers, display :
a. first name.
b. monthly discount.
c. monthly discount after addition of 19.7%.
d. monthly discount after addition of 19.7%, expressed as a whole number
(ROUND).
e. monthly discount after addition of 19.7%, round down to the nearest whole
number (FLOOR).
f. monthly discount after addition of 19.7%, round up to the nearest whole
number (CEILING).*/

select  first_name,last_name,monthly_discount, monthly_discount+(monthly_discount*0.197) as monthlydiscountaftraddof19, 
			ROUND(monthly_discount+(monthly_discount*0.197),0) as Ronudedmonthly_discount,
			FLOOR(monthly_discount+(monthly_discount*0.197)) as florredmonthly_discount,
			CEILING(monthly_discount+(monthly_discount*0.197)) as ceiledmonthly_discount
from customers

/*44. From Customers table, for all customers, display the first name, join date, join date
minus 10 days, join date plus one month and the date difference between join date
and current date.*/

select first_name,join_date,dateadd(dd,-10,join_date) AS DOJMINUS10DAYS,dateadd(dd,+10,join_date) AS DOJPLUS10DAYS,dateDiff(dd,join_date,Birth_date)AS DIFFERENCEINDAYS from customers

/*45. Display the first name, birthdate and age for all customers whose older than 50.*/

SELECT first_name,Birth_date,DATEDIFF(yy,Birth_date,GETDATE()) as Age FROM customers

/*46. Display all the data from Customers table, for all customers whose birthdate is today.*/

select * from customers
where Birth_date = GETDATE()

/*47. Display the first name, join date and the difference in years between join date and
current date for all customers where today have passed exactly 5 years since they
joined the company.*/

select first_name,join_date,DATEDIFF(yy,join_date,getdate()) as Experience from customers
where DATEDIFF(yy,join_date,getdate()) >5

/*48. Display the first name concatenated with the join date, and last name concatenated
with the monthly discount, for all customers. Solve this exercise using CAST.*/

select concat(first_name,cast(join_date as varchar)),concat(last_name,cast(monthly_discount as int)) from customers

/*49. From Customers table, for all customers whose last name starts with a d or k, display:
a. last name
b. state in uppercase concatenated with customer number
c. join date concatenated with birthdate
Solve this exercise using CONVERT, and in the WHERE clause instead of using
LIKE, try to define the filtering condition using SUBSTRING.*/

select last_name,CONCAT(UPPER(customerstate),' ' ,Customer_id) , concat(convert(varchar(11),join_date,106),'  ',CONVERT(varchar(11),Birth_date,106)) from customers
where last_name LIKE '[S|k]%'

select last_name,CONCAT(UPPER(customerstate),' ' ,Customer_id) , concat(convert(varchar(11),join_date,106),'  ',CONVERT(varchar(11),Birth_date,106)) from customers
where  substring(last_name,1,1)in('S','k')

/*50. Phone numbers report:
a. Display the first name, last name, birth date, main phone number and
secondary phone number for all customers whose package number equals 27.
Copyright � 2016, Tech Mahindra. All rights reserved.
Replace every null value in main phone number or in secondary phone number
with �N/A�.*/

select first_name,last_name,Birth_date,main_phone_num,secondary_phone_num,ISNULL(main_phone_num,'N/A') as newmainphonenumber,ISNULL(secondary_phone_num,'N/A') as newsecphonenum from customers
where pack_id = 4 OR main_phone_num IS NULL OR secondary_phone_num IS NULL

select first_name,last_name,Birth_date,main_phone_num,secondary_phone_num,COALESCE(main_phone_num,'N/A') as newmainphonenumber,COALESCE(secondary_phone_num,'N/A') as newsecphonenum from customers
where pack_id = 4 OR main_phone_num IS NULL OR secondary_phone_num IS NULL


/*b. Display the first name, last name, birth date, main phone number, secondary
phone number for all customers who was born on 1972. Replace every null
value in main phone number or in secondary phone number with �N/A�.*/

select first_name,last_name,Birth_date,main_phone_num,secondary_phone_num from customers
where YEAR(Birth_date) = '1974'

/*51. From Customers table, for all customers, display the first name, last name, monthly
discount and a discount grade based on these conditions :
a. If the discount is between 0 and 10 � discount grade level is A.
b. If the discount is between 11 and 20 � discount grade level is B.
c. If the discount is between 21 and 30 � discount grade level is C.
d. for any other value � discount grade level is D.*/

SELECT first_name,last_name,monthly_discount,
	CASE
		WHEN monthly_discount BETWEEN 0 AND 10 THEN 'A'
		WHEN monthly_discount BETWEEN 11 AND 20 THEN 'B'
		WHEN monthly_discount BETWEEN 21 AND 30 THEN 'C'
		ELSE 'D'
	END 'Grades' 
FROM customers

/*52. Display the lowest last name alphabetically (Customers table).*/

select min(last_name) as Lowestlastname from customers

/*53. Display the average monthly payment (Packages table).*/

select AVG(monthly_payment) as Avgofmonthlypayement from packages group by monthly_payment

/*54. Display the highest last name alphabetically (Customers table).*/

select max(last_name) as Lowestlastname from customers

/*55. Display the number of internet packages (Packages table).*/

select count(pack_id)as numberofpackages from packages

/*56. Display the number of records in Customers table.*/

select count(pack_id)as numberofpackages from packages

/*57. Display the number of distinct states (Customers table).*/

select count(distinct(customerstate)) as Distinctstates from customers

/*58. Display the number of distinct internet speeds (Packages table).*/

select count(distinct(speed)) as Distinctspeeds from packages

/*59. Display the number of values (exclude Nulls) in Fax column (Customers table).*/

select count(fax)from customers
where fax IS NOT NULL

/*60. Display the number of Null values in Fax column (Customers table).*/

select count(fax) from customers
where fax IS NULL

/*61. Display the highest, lowest and average monthly discount (Customers table).*/

select max(monthly_discount) as highestmonthlydiscount, min(monthly_discount) as lowestmonthlydiscount ,avg(monthly_discount) from customers

/*62. Display the state and the number of customers for each state (Customers table).*/

select customerstate,count(Customer_id)as cutomersofstate from customers
group by customerstate

/*63. Display the internet speed and the average monthly payment for each speed
(Packages table).*/

select speed,avg(monthly_payment)  as Avgofmonthly_payement from packages
group by speed

/*64. Display the state and the number of distinct cities for each state (Customers table).*/

select customerstate,count(distinct(city)) from customers
group by customerstate

/*65. Display the sector number and the highest monthly payment for each sector
(Packages table).*/

select sector_id,max(monthly_payment) from packages
group by sector_id

/*66. Package number and average monthly discount (Customers table) �
a. Display the package number and the average monthly discount for each
package.*/

select pack_id,avg(monthly_discount) from customers
group by pack_id

/*b. Display the package number and the average monthly discount for each
package, only for packages whose number equals 22 or 13.*/

select pack_id,avg(monthly_discount) from customers
where pack_id = 2 or pack_id = 3
group by pack_id

/*67. Display the highest, lowest and average monthly payment for each internet speed
(Packages table).*/

select max(monthly_payment),min(monthly_payment),avg(monthly_payment) from packages
group by speed

/*68. The number of customer in each internet package (Customers table) �
a. Display the package number and the number of customers for each package
number.*/

select pack_id,count(Customer_id) from customers
group by pack_id

/*b. Modify the query to display the package number and number of customers for
each package number, only for the customers whose monthly discount is
greater than 20.*/

select pack_id,count(Customer_id) from customers
where monthly_discount > 20
group by pack_id

/*c. Modify the query to display the package number and number of customers for
each package number, only for the packages with more than 100 customers.*/

select pack_id,count(Customer_id) from customers
group by pack_id
having count(Customer_id) >=100

/*69. Display the state, city and number of customers for each state and city.*/

select customerstate,city,COUNT(customer_id) as no_of_customer
from customers
group by customerstate, city

/*70. Cities and the average monthly discount (Customers table) �
a. Display the city and the average monthly discount for each city
Copyright � 2016, Tech Mahindra. All rights reserved.*/

 select city,AVG(monthly_discount)
from customers 
group by city

/*b. Display the city and the average monthly discount for each city, only for the
customers whose monthly discount is greater than 20*/

select city,AVG(monthly_discount)
from customers 
where monthly_discount>20
group by city


/*71. States and the lowest monthly discount (Customers table) �
a. Display the state and the lowest monthly discount for each state.*/

select min(monthly_discount) as min_monthly_discount, customerstate 
from customers 
group by customerstate

/*b. Display the state and lowest monthly discount for each state, only for states
where the lowest monthly discount is greater than 10*/

select min(monthly_discount) as min_monthly_discount, customerstate 
from customers where(monthly_discount > 10)
group by customerstate

/*72. Display the internet speed and number of package for each internet speed, only for the
internet speeds with more than 8 packages.*/

select count(speed), speed  from packages 
group by speed having count(speed)>  8

/*73. Customers and internet packages (Customers & Packages tables) �
a. Write a query to display first name, last name, package number and internet
speed for all customers.*/

select first_name, last_name, packages.pack_id, speed from customers,packages;

SELECT customers.pack_id
FROM packages
INNER JOIN customers ON packages.pack_id = customers.pack_id;

/*b. Write a query to display first name, last name, package number and internet
speed for all customers whose package number equals 22 or 27. Order the
query in ascending order by last name.*/

select first_name, last_name, packages.pack_id, speed  
from customers,packages 
where (packages.pack_id =22 OR packages.pack_id=27)

SELECT customers.pack_id
FROM packages
INNER JOIN customers ON packages.pack_id = customers.pack_id;


/*74. Internet packages and sectors �
a. Display the package number, internet speed, monthly payment and sector
name for all packages (Packages and Sectors tables).*/

 select pack_id, monthly_payment, speed, sector_name  
from sectors,packages
where sectors.sector_id=packages.sector_id;

/*b. Display the customer name, package number, internet speed, monthly payment
and sector name for all customers (Customers, Packages and Sectors tables).*/

SELECT customers.first_name,packages.pack_id,packages.speed,packages.monthly_payment,sectors.sector_name
FROM customers 
INNER JOIN 
(packages INNER JOIN sectors
ON sectors.sector_id=packages.pack_id) 
ON customers.customer_id=packages.pack_id

/*c. Display the customer name, package number, internet speed, monthly payment
and sector name for all customers in the business sector (Customers,
Packages and Sectors tables).*/

SELECT customers.first_name,packages.pack_id,packages.speed,packages.monthly_payment,sectors.sector_name
FROM customers 
INNER JOIN 
(packages INNER JOIN sectors
ON sectors.sector_id=packages.pack_id) 
ON customers.customer_id=packages.pack_id
where sectors.sector_name='Business';

/*75. Display the last name, first name, join date, package number, internet speed and sector
name for all customers in the private sector who joined the company in the year 2006.*/

SELECT customers.first_name,customers.last_name,customers.join_date,packages.pack_id,packages.speed,packages.monthly_payment,sectors.sector_name
FROM customers 
INNER JOIN 
(packages INNER JOIN sectors
ON sectors.sector_id=packages.pack_id) 
ON customers.customer_id=packages.pack_id
where customers.join_date='2006' and sectors.sector_name='Private';

/*76. Display the package number, internet speed, monthly payment and package grade for
all packages (Packages and Pack_Grades tables).*/

select p.pack_id,p.speed,p.monthly_payment,pg.grade_id
from packages p 
JOIN pack_grades pg
on  p.pack_id = pg.grade_id

/*77. Customers and internet packages (Customers and Packages tables)
a. Display the first name, last name, internet speed and monthly payment for all
customers. Use INNER JOIN to solve this exercise.
b. Modify last query to display all customers, including those without any internet
package.
c. Modify last query to display all packages, including those without any
customers.
d. Modify last query to display all packages and all customers.*/

select concat(c.First_Name,' ',c.Last_Name),p.pack_id,p.speed,p.monthly_payment
from customers c 
inner join packages p
on (c.pack_id=p.pack_id)

/*78. Display the last name, first name and package number for all customers who have the
 same package number as customer named �Amado Taylor� (Customers table).*/

 select c.First_Name,c.Last_Name,c.pack_id
from customers c 
join customers c1
on (c.pack_id=c1.pack_id)
where c1.Last_Name = 'Taylor' AND c1.First_Name = 'Amado'

/*79. Display the last name, first name and monthly discount for all customers whose
monthly discount is lower than the monthly discount of employee number 103
(Customers table).*/

select c.First_Name,c.Last_Name,c.pack_id,c1.monthly_discount
from customers c 
join customers c1
on (c.pack_id=c1.pack_id)
where  c1.Customer_id = 103
       AND c.monthly_discount < c1.monthly_discount

	   --OR--
select First_Name , Last_Name ,pack_id,monthly_discount
from customers
where monthly_discount < (select monthly_discount from customers where customer_id = 170)

/*80. Display the package number and internet speed for all packages whose internet speed
is equal to the internet speed of package number 10 (Packages table).*/

select speed,pack_id from
 packages where speed=(select speed from packages
 where pack_id=10)

/*81. Display the first name, last name, city and state for all customers who live in the same
state as customer number 170 (Customers table).*/

select first_name,last_name,city,customerstate from customers
 where customerstate=(select customerstate from customers 
 where customer_id=17)

/*82. Display the package number, internet speed and sector number for all packages
whose sector number equals to the sector number of package number 10 (Packages
table).*/

select pack_id,speed,sector_id from packages
where sector_id=(select sector_id from packages 
where pack_id=10)

/*83. Display the first name, last name and join date for all customers who joined the
company after customer number 540 (Customers table).*/

select first_name,last_name,join_date from customers
where join_date >(select join_date from customers 
where customer_id =5)

/*84. Display the first name, last name and join date for all customers who joined the
company on the same month and on the same year as customer number 372
(Customers table).*/

SELECT first_name , last_name , join_date
FROM customers
WHERE year(join_date) = (SELECT year(join_date) FROM customers WHERE customer_id = 3)
AND
month(join_date) = (SELECT month(join_date) FROM customers WHERE customer_id = 3)
 
/*85. Display the first name, last name, city, state and package number for all customers
whose internet speed is �5Mbps� (Customers and Packages table).*/

SELECT first_name , last_name , city , customerstate, pack_id
FROM customers
WHERE pack_id IN (SELECT pack_id FROM packages WHERE speed = '5Mbps')
 
/*86. Display the package number, internet speed and strt_date (the date it became
available) for all packages who became available on the same year as package
number 7 (Packages table).*/

SELECT pack_id , speed , strt_date
FROM packages
WHERE year(strt_date) = (SELECT year(strt_date) FROM packages WHERE pack_id = 7)

/*87. Display the first name, monthly discount, package number, main phone number and
secondary phone number for all customers whose sector name is Business
(Customers, Packages and Sectors tables).*/

SELECT first_name , monthly_discount , pack_id , main_phone_num ,
                    secondary_phone_num
FROM customers
WHERE pack_id IN
        (SELECT pack_id
            FROM packages
            WHERE sector_id IN
                    (   SELECT sector_id
                        FROM sectors
                        WHERE sector_name = 'Business'))

/*88. Display the first name, monthly discount and package number for all customers whose
monthly payment is greater than the average monthly payment (Customers and
Packages table).*/

SELECT first_name , monthly_discount, pack_id
FROM customers
WHERE pack_id IN
                 (SELECT  pack_id
                  FROM packages
                  WHERE monthly_payment >
                             (SELECT AVG(monthly_payment)
                              FROM packages))
 
/*89. Display the first name, city, state, birthdate and monthly discount for all customers
who was born on the same date as customer number 179, and whose monthly
discount is greater than the monthly discount of customer number 107 (Customers
table)*/

SELECT customer_id , first_name , city , customerstate ,birth_date , monthly_discount
FROM customers
WHERE birth_date =
             (SELECT birth_date FROM customers WHERE customer_id = 10)
              AND
              monthly_discount >
                 (SELECT monthly_discount FROM customers WHERE customer_id = 10)
 
/*90. Display all the data from Packages table for packages whose internet speed equals to
the internet speed of package number 30, and whose monthly payment is greater than
the monthly payment of package number 7 (Packages table).*/

SELECT * FROM packages
WHERE speed =
         (SELECT speed FROM packages WHERE pack_id = 30)
AND
             monthly_payment >
             (SELECT monthly_payment FROM packages WHERE pack_id = 7)
 
/*91. Display the package number, internet speed, and monthly payment for all packages
whose monthly payment is greater than the maximum monthly payment of packages
with internet speed equals to �5Mbps� (Packages table).*/

SELECT pack_id ,speed , monthly_payment
FROM packages
WHERE monthly_payment
        > ALL(SELECT monthly_payment FROM packages WHERE speed = '5Mbps')

/*92. Display the package number, internet speed and monthly payment for all packages
whose monthly payment is greater than the minimum monthly payment of packages
with internet speed equals to �5Mbps� (Packages table).*/

SELECT pack_id ,speed , monthly_payment
FROM packages
WHERE monthly_payment >
         ANY (SELECT monthly_payment FROM packages WHERE speed = '5Mbps')
 
/*93. Display the package number, internet speed and monthly payment for all packages
whose monthly payment is lower than the minimum monthly payment of packages
with internet speed equals to �5Mbps� (Packages table).*/

SELECT pack_id ,speed , monthly_payment
FROM packages
WHERE monthly_payment
         < ANY (SELECT monthly_payment FROM packages WHERE speed = '5Mbps')
 
/*94. Display the first name, monthly discount and package number for all customers whose
monthly discount is lower than the average monthly discount, and whose package
number is the same as customer named �Kevin�*/

SELECT first_name ,monthly_discount , pack_id
FROM customers
WHERE monthly_discount <
        (SELECT AVG(monthly_discount) FROM customers)
AND
             pack_id IN
             (SELECT pack_id FROM customers WHERE first_name = 'Kevin')
